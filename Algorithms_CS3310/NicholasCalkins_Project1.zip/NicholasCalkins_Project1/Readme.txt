Nicholas Calkins
October 25th, 2019
CS 3310 - Design and Analysis of Algorithms
Professor Tannaz R. Damavandi

				       Project #1 README

This is the content of project #1 for Nicholas Calkins.

*******************************************************************************

HOW TO RUN TASK #1
cd Sorting
javac MergeSort.java Quicksort.java SortTest.java
java SortTest
Respond to the program by giving it an appropriate n

Alternatively, just run the jar and respond to the program.

*******************************************************************************

HOW TO RUN TASK #2
cd Hanoi
javac Hanoi.java HanoiTester.java
java HanoiTester
Respond to the program by giving it an appropriate n

Alternatively, just run the jar and respond to the program.

*******************************************************************************

HOW TO RUN TASK #3
cd Matrix
javac Classic.java Strassen.java Driver.java
java Driver
Respond to the program by giving it an appropriate n

Alternatively, just run the jar and respond to the program

*******************************************************************************

Alternatively, these files can be uploaded to some IDE and run, wherever a Java
compiler can be found. These files were created and run on my Ubuntu OS.
